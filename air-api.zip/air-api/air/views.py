import json
from django.shortcuts import HttpResponse
from datetime import datetime
from air.models import Air
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, InvalidPage
from django.http import JsonResponse
from django.shortcuts import get_object_or_404


def list(request):
    # Use values() method to retrieve only specific fields
    res = Air.objects.all().values(
        'id', 'airCode', 'airCna', 'status',
        'reserve1', 'reserve2', 'reserve3', 'reserve4',
        'reserve5', 'airC', 'airF', 'airFna', 'airTotal',
        'airY', 'airYna'
    )

    # Use list comprehension to convert QuerySet to a list of dictionaries
    resList = [college for college in res]

    # Use JsonResponse instead of manually formatting the response content
    content = {
        'success': True,
        'message': '查询成功',
        'data': resList
    }
    return JsonResponse(content, json_dumps_params={'ensure_ascii': False})


def info(request):
    # Extract the 'id' parameter from query string
    id = request.GET.get('id')

    # Use get_object_or_404 to retrieve single object or raise Http404 exception
    re = get_object_or_404(Air, id=id)

    # Construct dictionary directly instead of using loop
    newre = {
        'id': re.id,
        'airCode': re.airCode,
        'airCna': re.airCna,
        'status': re.status,
        'reserve1': re.reserve1,
        'reserve2': re.reserve2,
        'reserve3': re.reserve3,
        'reserve4': re.reserve4,
        'reserve5': re.reserve5,
        'airC': re.airC,
        'airF': re.airF,
        'airFna': re.airFna,
        'airTotal': re.airTotal,
        'airY': re.airY,
        'airYna': re.airYna
    }

    # Use JsonResponse instead of manually formatting the response content
    content = {
        'success': True,
        'message': '查询成功',
        'data': newre
    }
    return JsonResponse(content, json_dumps_params={'ensure_ascii': False})


def info1(request):
    query_dict = request.GET
    airCode = query_dict.get('airCode')
    re=Air.objects.get(airCode=airCode)
    newre={}
    newre['id'] =re.id
    newre['airCode'] =re.airCode
    newre['airCna'] =re.airCna
    newre['status'] =re.status
    newre['reserve1'] =re.reserve1
    newre['reserve2'] =re.reserve2
    newre['reserve3'] =re.reserve3
    newre['reserve4'] =re.reserve4
    newre['reserve5'] =re.reserve5
    newre['airC'] =re.airC
    newre['airF'] =re.airF
    newre['airFna'] =re.airFna
    newre['airTotal'] =re.airTotal
    newre['airY'] =re.airY
    newre['airYna'] =re.airYna
    content = {
                'success': True,
                'message': '查询成功',
                'data':newre
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')


def delete(request):
    query_dict = request.GET
    id = query_dict.get('id')
    re=Air.objects.get(id=id).delete()
    content = {
                'success': True,
                'message': '删除成功',
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')


def save(request):
    jsonData = json.loads(request.body.decode())
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    air = Air()

    air.airCode = jsonData.get('airCode', None)
    air.airCna = jsonData.get('airCna', None)
    air.status = jsonData.get('status', None)
    air.reserve1 = jsonData.get('reserve1', None)
    air.reserve2 = jsonData.get('reserve2', None)
    air.reserve3 = jsonData.get('reserve3', None)
    air.reserve4 = jsonData.get('reserve4', None)
    air.reserve5 = jsonData.get('reserve5', None)
    air.airC = jsonData.get('airC', None)
    air.airF = jsonData.get('airF', None)
    air.airFna = jsonData.get('airFna', None)
    air.airTotal = jsonData.get('airTotal', None)
    air.airY = jsonData.get('airY', None)
    air.airYna = jsonData.get('airYna', None)
    air.create_time = now
    air.save()

    content = {
        'success': True,
        'message': '新增成功',
        'data': jsonData
    }
    return HttpResponse(
        content=json.dumps(content, ensure_ascii=False),
        content_type='application/json; charset=utf-8'
    )


def update(request):
    # Extract the request JSON data
    jsonData = json.loads(request.body.decode())

    # Get the Air object to be updated by id
    air = get_object_or_404(Air, id=jsonData['id'])

    # Define a dictionary of attribute names and messages for debugging
    attribute_messages = {
        'airCode': 'airCode is null',
        'airCna': 'airCna is null',
        'status': 'status is null',
        'reserve1': 'reserve1 is null',
        'reserve2': 'reserve2 is null',
        'reserve3': 'reserve3 is null',
        'reserve4': 'reserve4 is null',
        'reserve5': 'reserve5 is null',
        'airC': 'airC is null',
        'airF': 'airF is null',
        'airFna': 'airFna is null',
        'airTotal': 'airTotal is null',
        'airY': 'airY is null',
        'airYna': 'airYna is null'
    }

    # Use a loop to update each attribute and print a message for debugging
    for key, message in attribute_messages.items():
        try:
            setattr(air, key, jsonData[key])
        except KeyError:
            print(message)

    # Save the updated Air object
    air.save()

    # Construct the response content
    content = {
        'success': True,
        'message': '修改成功',
        'data': jsonData
    }

    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                        content_type='application/json;charset = utf-8')


def page(request):
    data = json.loads(request.body.decode())
    pageNum = data.get('pageNum', 1)
    pageSize = data.get('pageSize', 10)
    search = data.get('search', None)

    if search:
        res1 = Air.objects.filter(name=search)
    else:
        res1 = Air.objects.all()

    paginator = Paginator(res1, pageSize)
    try:
        page = paginator.page(pageNum)
    except (PageNotAnInteger, EmptyPage):
        page = paginator.page(1)

    resList = []
    for p in page:
        college = {
            'id': p.id,
            'airCode': p.airCode,
            'airCna': p.airCna,
            'status': p.status,
            'reserve1': p.reserve1,
            'reserve2': p.reserve2,
            'reserve3': p.reserve3,
            'reserve4': p.reserve4,
            'reserve5': p.reserve5,
            'airC': p.airC,
            'airF': p.airF,
            'airFna': p.airFna,
            'airTotal': p.airTotal,
            'airY': p.airY,
            'airYna': p.airYna
        }
        resList.append(college)

    content = {
        'success': True,
        'message': '查询成功',
        'data': resList,
        'total': res1.count()
    }

    return HttpResponse(
        content=json.dumps(content, ensure_ascii=False),
        content_type='application/json; charset=utf-8'
    )

