import json
from django.shortcuts import HttpResponse
from django.http import JsonResponse
from datetime import datetime
from user.models import User
from django.core.paginator import Paginator, EmptyPage, InvalidPage
from django.forms.models import model_to_dict


def list(request):
    res=User.objects.filter().all()
    resList=[]
    for p in res:
        college = {}
        college['id'] =p.id
        college['username'] =p.username
        college['name'] =p.name
        college['password'] =p.password
        college['role'] =p.role
        college['status'] =p.status
        college['reserve1'] =p.reserve1
        college['reserve2'] =p.reserve2
        college['reserve3'] =p.reserve3
        college['reserve4'] =p.reserve4
        college['reserve5'] =p.reserve5
        resList.append(college)
    content = {
                'success': True,
                'message': '查询成功',
                'data':resList
            }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False),
                            content_type='application/json;charset = utf-8')


def info(request):
    query_dict = request.GET
    id = query_dict.get('id')
    user = User.objects.get(id=id)
    new_user = model_to_dict(user, fields=['id', 'username', 'name', 'role', 'status', 'reserve1', 'reserve2', 'reserve3', 'reserve4', 'reserve5'])
    content = {
        'success': True,
        'message': '查询成功',
        'data': new_user
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False), content_type='application/json;charset=utf-8')


def delete(request):
    query_dict = request.GET
    id = query_dict.get('id')
    User.objects.filter(id=id).delete()
    content = {
        'success': True,
        'message': '删除成功',
    }
    return JsonResponse(content, json_dumps_params={'ensure_ascii': False})


def save(request):
    jsonData = json.loads(request.body.decode())
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    user=User(username=jsonData.get('username'),
              name=jsonData.get('name'),
              password=jsonData.get('password'),
              role=jsonData.get('role'),
              status=jsonData.get('status'),
              reserve1=jsonData.get('reserve1'),
              reserve2=jsonData.get('reserve2'),
              reserve3=jsonData.get('reserve3'),
              reserve4=jsonData.get('reserve4'),
              reserve5=jsonData.get('reserve5'),
              create_time=now)
    user.save()
    content = {
        'success': True,
        'message': '新增成功',
        'data':jsonData
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False), content_type='application/json;charset=utf-8')


def update(request):
    jsonData = json.loads(request.body.decode())
    user = User.objects.filter(id=jsonData['id']).first()
    if user is None:
        return HttpResponse(status=404)
    try:
        user.username = jsonData['username']
        user.name = jsonData['name']
        user.password = jsonData['password']
        user.role = jsonData['role']
        user.status = jsonData['status']
        user.reserve1 = jsonData['reserve1']
        user.reserve2 = jsonData['reserve2']
        user.reserve3 = jsonData['reserve3']
        user.reserve4 = jsonData['reserve4']
        user.reserve5 = jsonData['reserve5']
        user.save()
        content = {
            'success': True,
            'message': '修改成功',
            'data': jsonData
        }
        return JsonResponse(content, json_dumps_params={'ensure_ascii': False})
    except KeyError as e:
        message = f'字段 {e} 不存在或格式不正确'
    except ValueError as e:
        message = f'字段 {e} 的值不正确'
    content = {
        'success': False,
        'message': message,
        'data': jsonData
    }
    return JsonResponse(content, status=400, json_dumps_params={'ensure_ascii': False})


def page(request):
    data = json.loads(request.body.decode())
    pageNum = data.get('pageNum', 1)
    pageSize = data.get('pageSize', 10)
    search = data.get('search', '')
    queryset = User.objects.all()
    if search:
        queryset = queryset.filter(name__icontains=search)
    total = queryset.count()
    paginator = Paginator(queryset, pageSize)
    try:
        page = paginator.page(pageNum)
    except (EmptyPage, InvalidPage):
        page = paginator.page(1)
    resList = []
    for user in page:
        resList.append({
            'id': user.id,
            'username': user.username,
            'name': user.name,
            'password': user.password,
            'role': user.role,
            'status': user.status,
            'reserve1': user.reserve1,
            'reserve2': user.reserve2,
            'reserve3': user.reserve3,
            'reserve4': user.reserve4,
            'reserve5': user.reserve5,
        })
    content = {
        'success': True,
        'message': '查询成功',
        'data': resList,
        'total': total,
    }
    return JsonResponse(content, json_dumps_params={'ensure_ascii': False})


def login(request):
    data = json.loads(request.body.decode())
    try:
        user = User.objects.get(username=data['username'])
        if user.password == data['password']:
            content = {
                'success': True,
                'message': '登录成功',
                'data': {
                    'username': user.username,
                    'name': user.name,
                    'role': 'airer',
                },
            }
        else:
            content = {
                'success': False,
                'message': '密码错误',
                'data': {},
            }
    except User.DoesNotExist:
        content = {
            'success': False,
            'message': '用户不存在',
            'data': {},
        }
    return JsonResponse(content, json_dumps_params={'ensure_ascii': False})

