import json
from django.shortcuts import HttpResponse
from flight.models import Flight
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage, InvalidPage
from django.http import JsonResponse
from django.utils import timezone


def list(request):
    flights = Flight.objects.all()
    flight_list = []
    for flight in flights:
        flight_dict = {
            'id': flight.id,
            'airCode': flight.airCode,
            'create_time': flight.create_time,
            'status': flight.status,
            'reserve1': flight.reserve1,
            'reserve2': flight.reserve2,
            'reserve3': flight.reserve3,
            'reserve4': flight.reserve4,
            'reserve5': flight.reserve5,
            'comCode': flight.comCode,
            'flag': flight.flag,
            'fliAaddress': flight.fliAaddress,
            'fliAtime': flight.fliAtime,
            'fliBaddress': flight.fliBaddress,
            'fliBtime': flight.fliBtime,
            'fliCfare': flight.fliCfare,
            'fliCnumber': flight.fliCnumber,
            'fliDiscount': flight.fliDiscount,
            'fliFfare': flight.fliFfare,
            'fliFnumber': flight.fliFnumber,
            'fliNo': flight.fliNo,
            'fliRefundtime': flight.fliRefundtime,
            'fliYfare': flight.fliYfare,
            'fliYnumber': flight.fliYnumber
        }
        flight_list.append(flight_dict)
    content = {
        'success': True,
        'message': '查询成功',
        'data': flight_list
    }
    return HttpResponse(
        content=json.dumps(content, ensure_ascii=False),
        content_type='application/json;charset=utf-8'
    )


def info(request):
    flight_id = request.GET.get('id')
    flight = Flight.objects.filter(id=flight_id).first()
    if not flight:
        response_data = {
            'success': False,
            'message': '查询失败，找不到该航班',
        }
    else:
        data = {
            'id': flight.id,
            'airCode': flight.airCode,
            'create_time': flight.create_time,
            'status': flight.status,
            'reserve1': flight.reserve1,
            'reserve2': flight.reserve2,
            'reserve3': flight.reserve3,
            'reserve4': flight.reserve4,
            'reserve5': flight.reserve5,
            'comCode': flight.comCode,
            'flag': flight.flag,
            'fliAaddress': flight.fliAaddress,
            'fliAtime': flight.fliAtime,
            'fliBaddress': flight.fliBaddress,
            'fliBtime': flight.fliBtime,
            'fliCfare': flight.fliCfare,
            'fliCnumber': flight.fliCnumber,
            'fliDiscount': flight.fliDiscount,
            'fliFfare': flight.fliFfare,
            'fliFnumber': flight.fliFnumber,
            'fliNo': flight.fliNo,
            'fliRefundtime': flight.fliRefundtime,
            'fliYfare': flight.fliYfare,
            'fliYnumber': flight.fliYnumber,
        }
        response_data = {
            'success': True,
            'message': '查询成功',
            'data': data,
        }
    return JsonResponse(response_data, json_dumps_params={'ensure_ascii': False})


def delete(request):
    flight_id = request.GET.get('id')
    flight = Flight.objects.filter(id=flight_id).first()
    if not flight:
        response_data = {
            'success': False,
            'message': '删除失败，找不到该航班',
        }
    else:
        flight.delete()
        response_data = {
            'success': True,
            'message': '删除成功',
        }
    return JsonResponse(response_data, json_dumps_params={'ensure_ascii': False})


def save(request):
    try:
        json_data = json.loads(request.body)
    except Exception:
        response_data = {
            'success': False,
            'message': '保存失败，请求数据格式不正确',
        }
        return JsonResponse(response_data, json_dumps_params={'ensure_ascii': False})
    now = timezone.now()
    flight = Flight(
        airCode=json_data.get('airCode'),
        status=json_data.get('status'),
        reserve1=json_data.get('reserve1'),
        reserve2=json_data.get('reserve2'),
        reserve3=json_data.get('reserve3'),
        reserve4=json_data.get('reserve4'),
        reserve5=json_data.get('reserve5'),
        comCode=json_data.get('comCode'),
        flag=json_data.get('flag'),
        fliAaddress=json_data.get('fliAaddress'),
        fliAtime=json_data.get('fliAtime'),
        fliBaddress=json_data.get('fliBaddress'),
        fliBtime=json_data.get('fliBtime'),
        fliCfare=json_data.get('fliCfare'),
        fliCnumber=json_data.get('fliCnumber'),
        fliDiscount=json_data.get('fliDiscount'),
        fliFfare=json_data.get('fliFfare'),
        fliFnumber=json_data.get('fliFnumber'),
        fliNo=json_data.get('fliNo'),
        fliRefundtime=json_data.get('fliRefundtime'),
        fliYfare=json_data.get('fliYfare'),
        fliYnumber=json_data.get('fliYnumber'),
        create_time=now,
    )
    flight.save()
    response_data = {
        'success': True,
        'message': '保存成功',
        'data': json_data,
    }
    return JsonResponse(response_data, json_dumps_params={'ensure_ascii': False})


def update(request):
    jsonData = json.loads(request.body.decode())
    flight = Flight.objects.get(id=jsonData['id'])

    for key in jsonData:
        try:
            setattr(flight, key, jsonData[key])
        except Exception:
            print(key, " is null")

    flight.save()
    content = {
        'success': True,
        'message': '修改成功',
        'data': jsonData
    }
    return HttpResponse(content=json.dumps(content, ensure_ascii=False), content_type='application/json;charset=utf-8')


def page(request):
    data = json.loads(request.body.decode())
    pageNum = data.get('pageNum', 1)
    pageSize = data.get('pageSize', 10)
    search = data.get('search', None)

    if search:
        res1 = Flight.objects.filter(reserve1=search)
    else:
        res1 = Flight.objects.all()

    paginator = Paginator(res1, pageSize)
    try:
        page = paginator.page(pageNum)
    except (PageNotAnInteger, EmptyPage):
        page = paginator.page(1)

    resList = []
    for p in page:
        college = {
            'id': p.id,
            'airCode': p.airCode,
            'create_time': p.create_time,
            'status': p.status,
            'reserve1': p.reserve1,
            'reserve2': p.reserve2,
            'reserve3': p.reserve3,
            'reserve4': p.reserve4,
            'reserve5': p.reserve5,
            'comCode': p.comCode,
            'flag': p.flag,
            'fliAaddress': p.fliAaddress,
            'fliAtime': p.fliAtime,
            'fliBaddress': p.fliBaddress,
            'fliBtime': p.fliBtime,
            'fliCfare': p.fliCfare,
            'fliCnumber': p.fliCnumber,
            'fliDiscount': p.fliDiscount,
            'fliFfare': p.fliFfare,
            'fliFnumber': p.fliFnumber,
            'fliNo': p.fliNo,
            'fliRefundtime': p.fliRefundtime,
            'fliYfare': p.fliYfare,
            'fliYnumber': p.fliYnumber
        }
        resList.append(college)

    content = {
        'success': True,
        'message': '查询成功',
        'data': resList,
        'total': res1.count()
    }

    return HttpResponse(
        content=json.dumps(content, ensure_ascii=False),
        content_type='application/json; charset=utf-8'
    )


def page1(request):
    data = json.loads(request.body.decode())
    pageNum = data.get('pageNum', 1)
    pageSize = data.get('pageSize', 10)
    search = {
        'reserve1': data.get('search', None),
        'fliBaddress': data.get('fliBaddress', None),
        'fliAaddress': data.get('fliAaddress', None),
        'fliBtime': data.get('fliBtime', None)
    }
    search_kwargs = {k: v for k, v in search.items() if v is not None}
    res1 = Flight.objects.filter(**search_kwargs)
    paginator = Paginator(res1, pageSize)
    try:
        page = paginator.page(pageNum)
    except (PageNotAnInteger, EmptyPage):
        page = paginator.page(1)

    resList = []
    for p in page:
        college = {
            'id': p.id,
            'airCode': p.airCode,
            'create_time': p.create_time,
            'status': p.status,
            'reserve1': p.reserve1,
            'reserve2': p.reserve2,
            'reserve3': p.reserve3,
            'reserve4': p.reserve4,
            'reserve5': p.reserve5,
            'comCode': p.comCode,
            'flag': p.flag,
            'fliAaddress': p.fliAaddress,
            'fliAtime': p.fliAtime,
            'fliBaddress': p.fliBaddress,
            'fliBtime': p.fliBtime,
            'fliCfare': p.fliCfare,
            'fliCnumber': p.fliCnumber,
            'fliDiscount': p.fliDiscount,
            'fliFfare': p.fliFfare,
            'fliFnumber': p.fliFnumber,
            'fliNo': p.fliNo,
            'fliRefundtime': p.fliRefundtime,
            'fliYfare': p.fliYfare,
            'fliYnumber': p.fliYnumber
        }
        resList.append(college)

    content = {
        'success': True,
        'message': '查询成功',
        'data': resList,
        'total': res1.count()
    }

    return HttpResponse(
        content=json.dumps(content, ensure_ascii=False),
        content_type='application/json; charset=utf-8'
    )
